# Installation
* Install Linux/ApachePHP/MySQL (this should work fine under nginx and other systems)
** Make sure you install `php-mysql` and `php-mcrypt`
* Create a database using `sprusage.sql`
** Create a MySQL user with full access to that database, and put its account in the variables on top of `db.php`
